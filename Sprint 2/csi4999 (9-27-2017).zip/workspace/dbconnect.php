<!--
Filename: dbconnect.php
Author: Jake Wierszewski
Purpose: Database connection
-->
<?php


 error_reporting( ~E_DEPRECATED & ~E_NOTICE );

 
 define('DBHOST', '127.0.0.1');
 define('DBUSER', 'dbconnect');
 define('DBPASS', 'dbconnect');
 define('DBNAME', 'dbtest');
 
 $conn = mysql_connect(DBHOST,DBUSER,DBPASS);
 $dbcon = mysql_select_db(DBNAME);
 
 if ( !$conn ) {
  die("Connection failed : " . mysql_error());
 }
 
 if ( !$dbcon ) {
  die("Database connection failed : " . mysql_error());
 }
 //<!-- End of File ****************************************************--> 