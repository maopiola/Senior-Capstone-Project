<!--
Filename: dashboard.php
Author: Jake Wierszewski
Purpose: Main menu (Navbar)/user dashboard

-->
<?php  //Start of PHP tag

 ob_start();
 session_start();
 require_once 'dbconnect.php';
 
 // if session is not set this will redirect to login page
 if( !isset($_SESSION['user']) ) {
  header("Location: index.php");
  exit;
 }


?> <!-- End PHP Tag -->
<!DOCTYPE HTML>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="style.css" type="text/css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.1.1.min.js"></script>
      
        <style>
            .panel {
                  background-color: #333;
                  border-color: #333;
                }
            
        </style>
    </head>
    <body style="background-color: #333"> 
     <nav class="navbar navbar-inverse">
             <div class="container-fluid">
               <div class="navbar-header">
                   <a class="navbar-brand" href="home.php">OU Indoor</a>
               </div>
             </div>
     </nav>
     <div class="panel panel-default">
         <div class="panel-body">
             <div class="container-fluid">
                <ul class="list-group">
                    <li class="list-group-item">Random Stuff 1</li>
                    <li class="list-group-item">Random Stuff 2</li>
                    <li class="list-group-item">Random Stuff 3</li>
                </ul>
            </div>
        </div> 
     </div>
    </body>
</html>
<!-- End of File ****************************************************--> 