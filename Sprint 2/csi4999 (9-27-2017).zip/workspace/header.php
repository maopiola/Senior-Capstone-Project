<!--
Filename: header.php
Author: Jake Wierszewski
Purpose: Main menu (Navbar)/user dashboard for before login
-Bootstrap implementation for style
-->
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <title>Site</title>
<!--
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
-->
         <!-- Latest compiled and minified CSS -->
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        
         <!-- Optional theme -->
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap-theme.min.css">
        
        <style>
           /* 
            #main { border: 1px solid yellow;
                    border-radius: 10px;
                    padding: 8px;
                    background-color: #FFF; }
           */
        </style>
    </head>
    <body>
        <nav class="navbar navbar-default navbar-inverse">
            <div class="container-fluid">
             <div class="navbar-header">
                <a class="navbar-brand" href="index.php">OU Indoor</a>
             </div>
             <div>
                <ul class="nav navbar-nav">
                    <li <?= ($pageid == 'home') ? 'class="active"' : '' ?>><a href="index.php">Home</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                      
                 <?php if ($USER) { ?>
                     <li <?= ($pageid == 'maps') ? 'class="active"' : '' ?>><a href="index.php">Maps</a></li>
                     <li><a href="#"><span class="glyphicon glyphicon-user"></span> <?= $USER->name ?></a></li>
                     <li><a href="login.php?logout=1&url=index.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                 
                 <?php } else{ ?>
                     <li <?= ($pageid == 'login') ? 'class="active"' : '' ?>><a href="logout.php">Login</a></li>
                     <li <?= ($pageid == 'reg') ? 'class="active"' : '' ?>><a href="register.php"><span class="glyphicon glyphicon-pencil"></span>Sign-Up</a></li>
                 <?php } ?>
                </ul>
              </div>
            </div>
        </nav>
    </body>
</html>
        <!-- End of File ****************************************************--> 