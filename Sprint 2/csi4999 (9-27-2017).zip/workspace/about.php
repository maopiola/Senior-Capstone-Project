<?php

require ('nav.php');
 ob_start();
 session_start();
?>
<!DOCTYPE html>
<html>
    <head>
    
    
        <style>
        .col-md-4 {
            color: gold;
            text-align: left;
        }
        .row {
            margin-top:60px;
        }
        </style>
    </head>

    <body>
        <div class="row">
          <div class="col-md-4">.col-md-4</div>
          <div class="col-md-4">.col-md-4</div>
          <div class="col-md-4">.col-md-4</div>
        </div>
    </body>
    
    <script>
    
    </script>
</html>