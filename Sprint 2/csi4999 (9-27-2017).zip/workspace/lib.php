<!--
Filename: lib.php
Author: Jake Wierszewski
Purpose: Database connection and general file connection for header and footer
-->

<?php
session_start();
require('dbconnect.php');

$USER = false;
update_info();


function output_header($pageid = false) {
    global $USER;
    include('header.php');
}

function output_footer() {
    include('footer.php');
}

function update_info() {
  global $USER;
}
//<!-- End of File ****************************************************--> 
  
