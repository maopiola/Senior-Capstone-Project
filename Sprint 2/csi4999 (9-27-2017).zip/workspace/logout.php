<!--
Filename: logout.php
Author: Jake Wierszewski
Purpose: Account Logout

-->
<?php
 session_start();   //creates a session or resumes the current one based on a session identifier
 if (!isset($_SESSION['user'])) {    //if session is not active for user, redirect to index.php
  header("Location: index.php");
 } else if(isset($_SESSION['user'])!="") {  //if session is active for user, redirect to home.php
  header("Location: home.php");
 }
 
 if (isset($_GET['logout'])) { //if button "logout" is requested for user  
  unset($_SESSION['user']);  //unset the current session for that user
  session_unset();   //unset the session in general
  session_destroy(); // destroy the session
  header("Location: index.php");  //redirect to index.php
  exit;  //exit if statement
 } // end php ↓
 ?>
 <!-- End of File ****************************************************--> 